var txtA;
var txtB;
var btn;
var tBody;
var table;
var i;
var lblMensaje;
var xhr;

window.addEventListener('load', function(){
    txtA = document.getElementById('text1');
    txtB = document.getElementById('text2');
    btn = document.getElementById('btn1');
    tBody = document.getElementById('cuerpo');
    table = document.getElementById('table1');
    lblMensaje = document.getElementById('mensaje');

    btn.addEventListener("click",Guardar=function(){AgregarPersonaHtml();});
    txtA.addEventListener("keypress",function(){restaurarBorderColor();});
    txtB.addEventListener("keypress",function(){restaurarBorderColor();});
});

window.addEventListener('load', TraerPersonas);

function TraerPersonas()
{
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = Callback; //Callback llama a CargarPersonas()
    xhr.open('GET', 'http://localhost:3000/traerpersonas', true);
    xhr.send();
}

// function CargarPersonas()
// {
//     i = -1;
//     tBody.innerHTML = "";
//     var aux = JSON.parse(xhr.response);
//     for (var index= 0; index < aux.length; index++) {
//         var obj = aux[index];
//         AgregarFila(obj);
//     }
// }

// function AgregarFila(obj)
// {
//     i++;
//     //alert (i);
//     table.style = "block";
//     tBody.innerHTML += "<tr><td name=n"+i+">"+obj.nombre+"</td><td name=a"+i+">"+obj.apellido+"</td>"+
//     "<td><input type=button id= "+i+" value=Eliminar onclick=Eliminar("+i+")>"+
//     "<input type=button id= "+i+" value=Modificar onclick=Modificar("+i+")></td></tr>";
// }

function CargarPersonas()
{
    tBody.innerHTML = "";
    table.style = "block";
    var aux = JSON.parse(xhr.response);
    for (var index= 0; index < aux.length; index++) 
    {
        tBody.innerHTML += "<tr><td name=n"+index+">"+aux[index].nombre+"</td><td name=a"+index+">"+aux[index].apellido+"</td>"+
        "<td><input type=button id= "+index+" value=Eliminar onclick=Eliminar("+index+")>"+
        "<input type=button id= "+index+" value=Modificar onclick=Modificar("+index+")></td></tr>";
    }
}



function AgregarPersonaHtml()
{
    if (txtA.value != "" && txtB.value != "") 
    {
        //var personaJson = {nombre: txtA.value, apellido: txtB.value};
        //AgregarFila(personaJson);
        AgregarPersonaServer(); //Envia la persona nueva al server
        restaurarTexto();
        MostrarMensaje("Se guardo la persona");
    }
    else
    {
        MostrarMensajeError("Debe ingresar nombre y apellido");
        restaurarTexto();
    } 
}

function AgregarPersonaServer()
{
    xhr = new XMLHttpRequest();
    var personaPost = "nombre="+txtA.value+"&apellido="+txtB.value;
    xhr.onreadystatechange = Callback2; //traer Personas
    xhr.open("POST","http://localhost:3000/agregarpersona",true);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");//va antes de send, siempre que se envie por post
    xhr.send(personaPost);
}

function EliminarPersonaServer(id)
{
    xhr = new XMLHttpRequest();
    var id1 = "indice="+ id;
    xhr.onreadystatechange = Callback2; //traer personas
    xhr.open("POST","http://localhost:3000/eliminarpersona",true);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xhr.send(id1);
}

function Eliminar(id) 
{
    //var boton = document.getElementById(id);
    EliminarPersonaServer(id);
    //boton.parentNode.parentNode.outerHTML = "";
    MostrarMensaje("Se elimino la persona"); 
}

function Modificar(id) 
{
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = Callback3; //carga los campos de texto de nombre y apellido con la persona
    xhr.open("GET","http://localhost:3000/traerpersona?indice="+id, true);
    xhr.send();
    
    btn.setAttribute("value", "Modificar");
    btn.removeEventListener("click", Guardar);
    btn.addEventListener("click", Modificar2=function(){ ModificarRegistro(id);})
}


function ModificarRegistro(id) 
{
    xhr = new XMLHttpRequest();
    var personaJson = {"nombre": txtA.value, "apellido": txtB.value};
    var obj = "indice="+ id+"&persona="+JSON.stringify(personaJson);
    xhr.onreadystatechange = Callback2;
    xhr.open("POST","http://localhost:3000/modificarpersona",true);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xhr.send(obj);

    btn.setAttribute("value", "Guardar");
    btn.removeEventListener("click", Modificar2);
    btn.addEventListener("click", Guardar=function(){AgregarPersonaHtml();});
    restaurarTexto();
    MostrarMensaje("Se modifico la persona");

}

function Callback()
{
    var div = document.getElementById('contenedor');  
    if(xhr.readyState == 4)
    {
        if(xhr.status == 200)
        {
            div.innerHTML = "";
            CargarPersonas();
        }
        else { div.innerHTML = "Error: " + xhr.Status + " " + xhr.StatusText; }
    }
    else { div.innerHTML = '<img src = "89.gif">';}
}

function Callback2()
{
    var div = document.getElementById('contenedor');  
    if(xhr.readyState == 4)
    {
        if(xhr.status == 200)
        {
           div.innerHTML = "";
           TraerPersonas();
        }
        else { div.innerHTML = "Error: " + xhr.Status + " " + xhr.StatusText; }
    }
    else { div.innerHTML = '<img src = "89.gif">';}
}

function Callback3()
{
    var div = document.getElementById('contenedor');  
    if(xhr.readyState == 4)
    {
        if(xhr.status == 200)
        {
           div.innerHTML = "";
           var persona = JSON.parse(xhr.response);
           txtA.value = persona.nombre;
           txtB.value = persona.apellido;
        }
        else { div.innerHTML = "Error: " + xhr.Status + " " + xhr.StatusText; }
    }
    else { div.innerHTML = '<img src = "89.gif">';}
}


function MostrarMensajeError(mensajeDeError)
{
    txtA.style.borderColor="red";
    txtB.style.borderColor="red";
    lblMensaje.style.color = "red";
    lblMensaje.innerHTML = mensajeDeError;
}

function MostrarMensaje(mensaje)
{
    lblMensaje.style.color = "gray";
    lblMensaje.innerHTML = mensaje;
}

function restaurarBorderColor() 
{
    txtA.style.borderColor="";
    txtB.style.borderColor="";
    lblMensaje.innerHTML = "";
}

function restaurarTexto()
{
    txtA.value = "";
    txtB.value = "";
}


//dejar comentado el setRequestHeader
        //hr.send(JSON.stringify(personaJson));
        //a este alert lo uso para probar que es lo que me devuelve el innerHTML del body
        //alert(tBodys.innerHTML);


 /*Aquí lo que hago dándole la propiedad block al style de la tabla, es hacer que vuelva a ser
        visible ya que en el html lo oculté, block lo hace visible en un lugar, e inline permite contenido
        flotante a un lado u otro del elemento */
        //table.style = "block";
        
//function Eliminar(id) 
        /*En principio a esta función la llamo desde el momento en que creo el botón dentro de la función
        Actualizar, ya que es allí donde le doy un id incremental a dicho botón que uso para poder identificar
        a cada botón de manera unívoca. En el momento de crear el botón, el id concedido a dicho botón se lo paso
        a esta función para que cree un objeto de este botón y pueda hacer algo con el. Mi variable botón guarda
        la referencia al botón creado, pero utilizando la propiedad "parentNode" de un objeto html, puedo usarla
        las veces como padre, abuelo, bisabuelo tenga un objeto, es decir en este caso del boton me muevo al 
        tag td con el primer parentNode y con el segundo me muevo al tag tr para igualarlo a "" lo que es lo
        mismo que borrarlo. para ello accedo al outerHTML que es similar al innerHTML, el inner nos permite
        manipular lo que se encuentra dentro del cuerpo contenido por el tag en el que estoy parado, y el 
        outer me permite manipular al tag en si, a la etiqueta en la que estoy parado.*/

//alert($nombre[0].innerHTML);

// window.onload = function(){
//     txtA = document.getElementById('text1');
//     txtB = document.getElementById('text2');
//     btn = document.getElementById('btn1');
//     tBody = document.getElementById('cuerpo');
//     table = document.getElementById('table1');

//     btn.addEventListener("click",Guardar=function(){AgregarPersonaHtml();});
//     txtA.addEventListener("keypress",function(){restaurarBorderColor();});
//     txtB.addEventListener("keypress",function(){restaurarBorderColor();});
// }

//     TraerPersonas();
// }

//Modificar()
//{
    // var nombre = document.getElementsByName('n'+id)[0];
    // var apellido = document.getElementsByName('a'+id)[0];
    // txtA.value = nombre.innerHTML;
    // txtB.value = apellido.innerHTML;

//ModificarRegistro()
    //nombreNuevo.innerHTML = txtA.value;
    //apellidoNuevo.innerHTML = txtB.value;
//}

