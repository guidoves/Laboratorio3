var xhr;

window.onload = function()
{
    var btnEntrar = document.getElementById("btnEntrar");
    btnEntrar.addEventListener('click',function()
    {
        agregarServer();        
    })
    
}

function agregarServer(){
    
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        var datosLogin = { email : email, password : password };
        xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function(){

            if (this.readyState == 4 && this.status == 200) {
                var res = JSON.parse(this.responseText);
                validacion(res);
            }
                

        };
        xhr.open('POST',"http://localhost:3000/login",true);
        xhr.setRequestHeader("Content-type", "application/JSON");
        xhr.send(JSON.stringify(datosLogin));    
}

function validacion(res){

    if(res.type == "error"){

        var out = '<h4 id="error">Debe usar un email y un password valido</h4>';
        document.getElementById("error").innerHTML = out;
    }
    else if(res.type == "Admin" || res.type == "User"){
        
        //Guarda los datos en el localStorage
        localStorage.setItem("Type",res.type);
        localStorage.setItem("Email",document.getElementById('email').value);
        
        //redirecciona
        window.location.href = "index.html";
        
    }
}

