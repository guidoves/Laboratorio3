var xhr;

window.onload = function()
{
    traerNoticias();
    
    
}

function traerNoticias(){

    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){

        if (this.readyState == 4 && this.status == 200) {
            var res = JSON.parse(this.responseText);
            cargaNoticias(res);
            if(localStorage.getItem("Type") == "Admin"){
                var nuevaNoticia = '<button id="btnNoticia" style='+"float:right"+'>Nueva Noticia</button>';
                document.getElementById('admin').innerHTML = nuevaNoticia;

                var btnNuevaNoticia = document.getElementById("btnNoticia");
                btnNuevaNoticia.addEventListener('click',function()
                {
                    window.open("","",'width=450,height=200,top = 50');        
                })
            
            }
        }
            

    };
    xhr.open('GET',"http://localhost:3000/noticias ",true);
    xhr.send();
}

function cargaNoticias(res){

    var out = "";
    res.forEach(function(element) {
        
        out += "<div><h1>"+element.titulo+"</h1><br><p>"+element.noticia+"</p><br>"+element.fecha+"</div><br>";

    }, this);

    document.getElementById('carga').innerHTML = out;

}